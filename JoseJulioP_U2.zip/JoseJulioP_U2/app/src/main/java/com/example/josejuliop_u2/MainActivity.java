package com.example.josejuliop_u2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;


public class MainActivity extends AppCompatActivity {



    private String[] nombres = new String[]{"Pestaña 1","Pestaña 2","Pestaña 3" , "Pestaña 4"};

    private String mostrar = "";
    private boolean espeseta = false;
    private double sumando = 0;

    private EditText entrada ;
    private TextView salida;

    private static boolean isNumeric(String cadena){
        try {
            Integer.parseInt(cadena);
            return true;
        } catch (NumberFormatException nfe){
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewPager2 viewPager = findViewById(R.id.viewpager);
        viewPager.setAdapter(new MiPagerAdapter(this));
        TabLayout tabs = findViewById(R.id.tabs);
        new TabLayoutMediator(tabs, viewPager,
                new TabLayoutMediator.TabConfigurationStrategy() {
                    @Override
                    public void onConfigureTab(@NonNull TabLayout.Tab tab, int position){
                        tab.setText(nombres[position]);
                    }
                }
        ).attach();




        entrada = findViewById(R.id.entrada);
        salida = findViewById(R.id.salida);
    }

    public void sePulsa(View view){
        entrada = findViewById(R.id.entrada);
        salida = findViewById(R.id.salida);
        Toast.makeText(this, "Pulsado", Toast.LENGTH_SHORT).show();
        if (isNumeric(String.valueOf(entrada.getText()))){
            salida.setText(String.valueOf(Float.parseFloat(
                    entrada.getText().toString()) * 2.0));
        }else{
            salida.setText("0");
        }
    }

    public void sePulsa0(View view){
        entrada = findViewById(R.id.entrada);
        salida = findViewById(R.id.salida);
        entrada.setText(entrada.getText()+(String)view.getTag());
    }

    public class MiPagerAdapter extends FragmentStateAdapter {
        public MiPagerAdapter(FragmentActivity activity){
            super(activity);
        }
        @Override
        public int getItemCount() {
            return 4;
        }
        @Override @NonNull
        public Fragment createFragment(int position) {
            switch (position) {
                case 0: return new Tab1();
                case 1: return new Tab2();
                case 2: return new Tab3();
                case 3: return new Tab4();
            }
            return null;
        }
    }



    public void escribe (View view){
        TextView res = findViewById(R.id.resText);
        Button b = findViewById(view.getId());
        String texto = (String) b.getText();
        if (isNumeric(texto)){
            mostrar += b.getText();
            res.setText(mostrar);
        }else{
            res.setText("El dato introducido no es un numero");
            mostrar = "";
        }

    }


    public void convert (View view){
        double numero = Double.parseDouble(mostrar);
        if (espeseta){
            numero /= 166.386;
            mostrar = String.valueOf(numero);
            espeseta = false;
        }else{
            numero *= 166.386;
            mostrar = String.valueOf(numero);
            espeseta=true;
        }
        TextView res = findViewById(R.id.resText);
        res.setText(mostrar);
    }

    public void borra (View view){
        mostrar = "";
        TextView res = findViewById(R.id.resText);
        res.setText(mostrar);
    }


    public void suma (View view){
        sumando = Double.parseDouble(mostrar);
        mostrar = "";
    }

    public void igual (View view){
        double sumando2 = Double.parseDouble(mostrar);
        double resul = sumando2 + sumando;
        mostrar = String.valueOf(resul);
        TextView res = findViewById(R.id.resText);
        res.setText(mostrar);
        sumando = 0;
    }
}