package com.example.josejuliop_u2;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class funcionBoton {

    private EditText entrada;
    private TextView salida;

}
